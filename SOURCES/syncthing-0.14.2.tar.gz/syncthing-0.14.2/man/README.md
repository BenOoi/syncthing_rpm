These manual pages are generates on http://docs.syncthing.net/, based on
the https://github.com/syncthing/docs repo. Do not edit them in this
repo.
